//6-5 생성자 함수2

function Account(owner, balance) {

  this.owner = owner;       
  this.balance = balance; 
  this.deposit = function(amount) {
    this.balance += amount;
  };

  this.withdraw = function(amount) {
    this.balance -= amount;
  };

  this.getBalance = function() {
    return this.balance;
  };
}