//6-3 객체 메소드
let calculator = {
  read: (a, b) => {
    calculator.a = a;
    calculator.b = b;
  },
  sum: () => {
    return calculator.a + calculator.b;
  },
  mul: () => {
    return calculator.a * calculator.b;
  }
};

calculator.read(1, 2);
console.log( calculator.sum() );
console.log( calculator.mul() );