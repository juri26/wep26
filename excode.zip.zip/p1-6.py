let myAccount = new Account("홍길동", 10000);

console.log(`계좌주인: ${myAccount.owner}`); 
console.log(`초기 잔고: ${myAccount.getBalance()}원`); 

myAccount.deposit(5000);
console.log(`5,000원 입금 후 잔고: ${myAccount.getBalance()}원`);
myAccount.withdraw(3000);
console.log(`3,000원 출금 후 잔고: ${myAccount.getBalance()}원`);