//6-2 객체 프로퍼티
let salaries = {
  John: 100,
  Ann: 160,
  Pete: 130
};


let sum = 0;

for (let key in salaries) {
  sum += salaries[key];
}

console.log(`팀원 월급의 총합: ${sum}`);
