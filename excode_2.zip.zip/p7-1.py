//1번
function sumOfDigits(n) {
  const str = n.toString();
  let sum = 0;

  for (let char of str) {
    sum += parseInt(char, 10);
  }

  return sum;
}

//2번
function sumOfNumbersInString(str) {
  let sum = 0;
  let currentNumStr = '';

  for (let i = 0; i <= str.length; i++) {
    const char = str[i];
    if (i < str.length && !isNaN(parseInt(char, 10))) {
      currentNumStr += char;
    } else {
      if (currentNumStr !== '') {
        sum += parseInt(currentNumStr, 10);
        currentNumStr = '';
      }
    }
  }

  return sum;
}

//3번
function binaryToHex(num) {
  const hexStr = num.toString(16).toUpperCase();
  return '0x' + hexStr;
}