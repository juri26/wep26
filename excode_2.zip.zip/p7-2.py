//1번
function capitalizeFirstLetter(str) {
  if (!str) return str;
  return str.charAt(0).toUpperCase() + str.slice(1);
}

//2번
function replaceMiddleWithSpace(str) {
  const mid = Math.floor(str.length / 2);
  return str.slice(0, mid) + ' ' + str.slice(mid + 1);
}