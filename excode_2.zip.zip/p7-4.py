function removeElement(arr, target) {
  return arr.filter((item) => item !== target);
}

const fruits = ["banana", "apple", "melon"];
const result = removeElement(fruits, "apple");

console.log(result);