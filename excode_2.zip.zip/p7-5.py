function reverseString(str) {
  const stack = [];
  let reversed = "";

  for (let char of str) {
    stack.push(char);
  }

  while (stack.length > 0) {
    reversed += stack.pop();
  }

  return reversed;
}

const str = "javascript";
console.log(reverseString(str));